package com.example.mapping.dto;

import lombok.Data;

@Data
public class LaptopDto {

    private String studentID;
    private String name;
    private String brand;
    private Integer price;

}
