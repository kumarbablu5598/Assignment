package com.example.mapping.dto;

import lombok.Data;

@Data
public class CourseStudentDto {

    private String studentId;
    private String courseId;

}
