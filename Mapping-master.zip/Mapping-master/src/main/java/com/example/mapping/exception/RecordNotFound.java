package com.example.mapping.exception;

public class RecordNotFound extends Throwable{
    public RecordNotFound(String message){
        super(message);
    }
}
