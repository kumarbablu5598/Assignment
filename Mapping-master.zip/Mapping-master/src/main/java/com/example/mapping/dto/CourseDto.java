package com.example.mapping.dto;

import lombok.Data;

@Data
public class CourseDto {

    private String ID;
    private String title;
    private String description;
    private String duration;

}
